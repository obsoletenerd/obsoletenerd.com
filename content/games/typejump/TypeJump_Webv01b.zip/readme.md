Add to full-size.html:

<script src="coi-serviceworker.min.js"></script>
